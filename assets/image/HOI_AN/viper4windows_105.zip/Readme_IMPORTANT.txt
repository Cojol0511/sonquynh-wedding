--- How to upgrade ViPER4Windows ---

1.Uninstall old ViPER4Windows from *START MENU* or *CONTROL PANEL*.
2.Install new ViPER4Windows with administrator permission (right click on installer, select run as administrator).
3.After installation, you need to reboot your computer.
4.If you got any problem when using ViPER4Windows, please run it with administrator permission first.
